document.addEventListener("DOMContentLoaded", function() {
    const pendaftaranLink = document.getElementById("pendaftaran-link");
    const modal = document.getElementById("notification-modal");
    const okButton = document.querySelector(".ok-button");

    pendaftaranLink.addEventListener("click", function(event) {
        event.preventDefault();
        modal.style.display = "block";
    });

    okButton.addEventListener("click", function() {
        modal.style.display = "none";
    });

    window.addEventListener("click", function(event) {
        if (event.target === modal) {
            modal.style.display = "none";
        }
    });

    const loginLink = document.getElementById("login-link");
    const loginDropdown = document.getElementById("login-dropdown");

    loginLink.addEventListener("click", function(event) {
        event.preventDefault();
        loginDropdown.classList.toggle("show");
    });

    window.addEventListener("click", function(event) {
        if (!event.target.matches('#login-link')) {
            if (loginDropdown.classList.contains('show')) {
                loginDropdown.classList.remove('show');
            }
        }
    });
});
